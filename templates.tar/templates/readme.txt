Collection of files useful for Service Containers creation
(C) 2015-2016 Cisco Systems

Revision 1.0 April 16th 2016 - First release

